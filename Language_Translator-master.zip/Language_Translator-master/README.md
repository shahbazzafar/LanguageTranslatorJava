# Language_Translator
An android app which will allows you to translate Hindi to English and English to Hindi with cool UI. It also supports voice input frature. It also supports real time audio translation.It also has some cutom animations.

## Android Screenshots

  Gif                 |   Screenshot 1                 
:-------------------------:|:-------------------------:
<img src="https://github.com/RahilBadshah/Language_Translator/blob/master/screenshots/preview_1.gif?raw=true" alt="drawing" width="320"  /> | <img src="https://github.com/RahilBadshah/Language_Translator/blob/master/screenshots/Screenshot_1.png?raw=true" alt="drawing" width="320"/>


#### Gradle
Add mlkit library
```groovy
dependencies {
  // ...

  implementation 'com.google.mlkit:translate:16.1.1'
}
```

### Getting Started
[Learn More](https://developers.google.com/ml-kit/language/translation/android#java)
